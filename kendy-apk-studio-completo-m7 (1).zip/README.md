# KENDY APK STUDIO (módulos 1 al 4)

Web para importar un APK, explorarlo, editar sus textos e imágenes, reconstruirlo, firmarlo y descargarlo.

## Estructura
- `index.html`  → pantalla (se aloja en Vercel, GitHub Pages, etc.)
- `backend/`    → API (Node + Fastify + PostgreSQL)
- `docker/`     → Dockerfile del backend (incluye aapt, zip, zipalign, apksigner y Java)
- `tests/`      → pruebas

## Backend en Render
1. New → PostgreSQL (Free).
2. New → Web Service → este repositorio → Language: Docker → Dockerfile Path: `docker/backend.Dockerfile`.
3. Variables de entorno: `DATABASE_URL`, `STORAGE_DIR=/data`, `MAX_APK_MB=50`, `KEYSTORE_PASSWORD` (8+ caracteres), `CORS_ORIGIN` (URL de tu web).
4. Abre `https://TU-SERVICIO.onrender.com/health`: debe salir `"ok": true`.
5. En la web → Configuración → pega la URL del backend → Diagnóstico.

## Local
    cp .env.example .env
    docker compose up --build

## Límites
- Los XML compilados, el manifiesto y el DEX no se editan todavía (requiere Apktool).
- "Compilada" no significa "probada en un dispositivo".
- La firma es distinta a la original: hay que desinstalar la app original para instalarla.
- En el plan gratuito de Render el disco se borra al reiniciar (APK, cambios y clave de firma).
