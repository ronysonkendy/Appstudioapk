import { describe, it, expect } from "vitest";
import { compareEntries } from "../backend/src/services/compare";

const e = (path: string, crc: number, size = 10) => ({ path, crc, size, isDir: false });

describe("compareEntries", () => {
  it("detecta añadidos, quitados y cambiados, e ignora la firma", () => {
    const a = [e("a.txt", 1), e("b.txt", 2), e("META-INF/CERT.RSA", 9), e("old.png", 5)];
    const b = [e("a.txt", 1), e("b.txt", 3, 20), e("META-INF/OTRA.RSA", 7), e("new.png", 6)];
    const r = compareEntries(a, b);
    expect(r.added).toEqual(["new.png"]);
    expect(r.removed).toEqual(["old.png"]);
    expect(r.changed).toEqual([{ path: "b.txt", sizeA: 10, sizeB: 20 }]);
    expect(r.counts).toEqual({ added: 1, removed: 1, changed: 1 });
  });
  it("sin diferencias", () => {
    expect(compareEntries([e("x", 1)], [e("x", 1)]).counts).toEqual({ added: 0, removed: 0, changed: 0 });
  });
});
